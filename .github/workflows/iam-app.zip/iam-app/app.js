const CATALOG = [
  { id: "trk-sovereign", type: "music", title: "The Sovereign", artist: "I AM", priceEth: 0.08, priceUsdc: 28, img: "assets/tarot.jpg", blurb: "Anthem drop. Gold-foil tarot cover + lossless audio." },
  { id: "trk-crown", type: "music", title: "I AM The Crown", artist: "I AM", priceEth: 0.11, priceUsdc: 42, img: "assets/artist.jpg", blurb: "Hood-rich spirit. Title track with exclusive verse." },
  { id: "spl-unbinding", type: "spell", title: "Unbinding", artist: "Grimoire", priceEth: 0.04, priceUsdc: 15, img: "assets/tarot.jpg", blurb: "Spell NFT: spoken working + written rite + 528Hz bed." },
  { id: "spl-mirror", type: "spell", title: "Void Mirror", artist: "Grimoire", priceEth: 0.05, priceUsdc: 18, img: "assets/studio.jpg", blurb: "Protection working. Cloak visualization + sigil lock." },
  { id: "sig-crownankh", type: "sigil", title: "Crown Ankh", artist: "Temple Walls", priceEth: 0.03, priceUsdc: 12, img: "assets/sigil.jpg", blurb: "Charged sigil medallion. Printable + lockscreen original." },
  { id: "bt-altar808", type: "beat", title: "Altar 808", artist: "I AM Beats", priceEth: 0.06, priceUsdc: 22, img: "assets/beats.jpg", blurb: "Exclusive lease-to-own beat. Stems unlock after mint." },
  { id: "bt-hyphyrite", type: "beat", title: "Hyphy Rite", artist: "I AM Beats", priceEth: 0.07, priceUsdc: 26, img: "assets/beats.jpg", blurb: "Bay bounce x temple drums. NFT includes WAV + trackout." },
  { id: "art-lilith", type: "deity", title: "Lilith, Street Queen", artist: "Pantheon", priceEth: 0.09, priceUsdc: 34, img: "assets/lilith.jpg", blurb: "Deity print. Sovereignty, untamed desire, night power." },
  { id: "art-isis", type: "deity", title: "Isis, Winged Gold", artist: "Pantheon", priceEth: 0.09, priceUsdc: 34, img: "assets/isis.jpg", blurb: "Restoration, throne, magic of making whole." },
  { id: "q-i-am", type: "quote", title: "I Am The One Not Defeated", artist: "Words", priceEth: 0.02, priceUsdc: 8, img: "assets/logo.jpg", blurb: "Quote relic. Affirmation card + audio stamp." }
];

const SHOWS = [
  { id: "live-rooftop", title: "Rooftop Rite — Live", when: "Tonight · looping preview", priceEth: 0.02, priceUsdc: 8, img: "assets/hero.jpg" },
  { id: "live-studio", title: "Temple Session", when: "Studio cut · on demand", priceEth: 0.015, priceUsdc: 6, img: "assets/studio.jpg" }
];

const state = {
  page: "home",
  wallet: null,
  filter: "all",
  cartItem: null,
  payAsset: "usdc",
  owned: JSON.parse(localStorage.getItem("iam-owned") || "[]"),
  minted: JSON.parse(localStorage.getItem("iam-minted") || "[]"),
  shoutouts: JSON.parse(localStorage.getItem("iam-shoutouts") || "[]"),
  tickets: JSON.parse(localStorage.getItem("iam-tickets") || "[]"),
  playing: false
};

function save() {
  localStorage.setItem("iam-owned", JSON.stringify(state.owned));
  localStorage.setItem("iam-minted", JSON.stringify(state.minted));
  localStorage.setItem("iam-shoutouts", JSON.stringify(state.shoutouts));
  localStorage.setItem("iam-tickets", JSON.stringify(state.tickets));
}

function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.style.display = "block";
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.style.display = "none"; }, 2800);
}

function shortAddr(a) { return a.slice(0, 6) + "…" + a.slice(-4); }

function go(page) {
  state.page = page;
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === "page-" + page));
  document.querySelectorAll(".nav-links a").forEach(a => a.classList.toggle("active", a.dataset.page === page));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function connectWallet() {
  if (state.wallet) {
    state.wallet = null;
    document.getElementById("walletBtn").textContent = "Connect Wallet";
    document.getElementById("walletBtn").classList.remove("connected");
    toast("Wallet disconnected");
    return;
  }
  const fake = "0xIAM" + Math.random().toString(16).slice(2, 12) + "c0ffee";
  state.wallet = fake.replace("IAM", "4a1");
  document.getElementById("walletBtn").textContent = shortAddr(state.wallet);
  document.getElementById("walletBtn").classList.add("connected");
  toast("Connected · Base / ETH + USDC ready (demo)");
}

function needWallet() {
  if (!state.wallet) {
    connectWallet();
  }
  return !!state.wallet;
}

function catalog() {
  return [...CATALOG, ...state.minted];
}

function renderMarket() {
  const root = document.getElementById("marketGrid");
  const items = catalog().filter(i => state.filter === "all" || i.type === state.filter);
  root.innerHTML = items.map(item => {
    const owned = state.owned.includes(item.id);
    return `
      <article class="card ${owned ? "owned" : ""}">
        <img class="cover" src="${item.img}" alt="${item.title}">
        <div class="body">
          <div class="tag">${item.type}</div>
          <h3>${item.title}</h3>
          <div class="meta">${item.artist}</div>
          <p class="meta">${item.blurb}</p>
          <div class="price">${item.priceEth} ETH · ${item.priceUsdc} USDC</div>
          <div class="cta-row" style="margin-top:12px">
            <button class="btn btn-gold" onclick="buyItem('${item.id}')">${owned ? "Owned" : "Collect"}</button>
          </div>
        </div>
      </article>`;
  }).join("");
}

function buyItem(id) {
  const item = catalog().find(i => i.id === id);
  if (!item) return;
  if (state.owned.includes(id)) return toast("Already in your vault");
  openPay({ kind: "nft", item });
}

function renderStage() {
  const root = document.getElementById("showList");
  root.innerHTML = SHOWS.map(s => {
    const has = state.tickets.includes(s.id);
    return `
      <article class="card">
        <img class="cover" src="${s.img}" alt="${s.title}" style="height:180px">
        <div class="body">
          <div class="tag">${has ? "ticket unlocked" : "paywalled rite"}</div>
          <h3>${s.title}</h3>
          <p class="meta">${s.when}</p>
          <div class="price">${s.priceEth} ETH · ${s.priceUsdc} USDC</div>
          <button class="btn btn-magenta" style="margin-top:12px" onclick="buyTicket('${s.id}')">${has ? "Enter again" : "Pay to enter"}</button>
        </div>
      </article>`;
  }).join("");
}

function buyTicket(id) {
  const item = SHOWS.find(s => s.id === id);
  if (state.tickets.includes(id)) {
    enterStage(id);
    return;
  }
  openPay({ kind: "ticket", item });
}

function enterStage(id) {
  const show = SHOWS.find(s => s.id === id);
  document.getElementById("nowPlayingTitle").textContent = show.title;
  document.getElementById("eq").classList.remove("off");
  state.playing = true;
  toast("You're in the rite. Audio bed is a preview tone.");
  startTone();
}

let audioCtx, osc, gain;
function startTone() {
  stopTone();
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    osc = audioCtx.createOscillator();
    gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.value = 528;
    gain.gain.value = 0.03;
    osc.connect(gain).connect(audioCtx.destination);
    osc.start();
  } catch (e) {}
}
function stopTone() {
  try { osc && osc.stop(); audioCtx && audioCtx.close(); } catch (e) {}
  osc = null; audioCtx = null;
  document.getElementById("eq").classList.add("off");
  state.playing = false;
}

function renderShoutouts() {
  const list = document.getElementById("shoutList");
  if (!state.shoutouts.length) {
    list.innerHTML = `<p class="meta">No shoutouts in the queue yet. First name on the wall sets the tone.</p>`;
    return;
  }
  list.innerHTML = state.shoutouts.slice().reverse().map(s => `
    <article class="card"><div class="body">
      <div class="tag">${s.asset.toUpperCase()} · ${s.paid}</div>
      <h3>@${s.name}</h3>
      <p>${s.message}</p>
      <p class="tiny">${s.time}</p>
    </div></article>
  `).join("");
}

function submitShout(e) {
  e.preventDefault();
  const name = document.getElementById("shoutName").value.trim();
  const message = document.getElementById("shoutMsg").value.trim();
  const asset = document.getElementById("shoutAsset").value;
  if (!name || !message) return toast("Name and message required");
  openPay({
    kind: "shout",
    item: {
      id: "shout-" + Date.now(),
      title: `Shoutout for ${name}`,
      priceEth: 0.025,
      priceUsdc: 10,
      name, message, asset
    }
  });
}

function mintNft(e) {
  e.preventDefault();
  if (!needWallet()) return;
  const type = document.getElementById("mintType").value;
  const title = document.getElementById("mintTitle").value.trim();
  const blurb = document.getElementById("mintBlurb").value.trim();
  const priceUsdc = Number(document.getElementById("mintPrice").value || 12);
  const priceEth = Math.max(0.01, +(priceUsdc / 380).toFixed(3));
  if (!title) return toast("Give it a name");
  const imgMap = { music: "assets/artist.jpg", spell: "assets/tarot.jpg", sigil: "assets/sigil.jpg", beat: "assets/beats.jpg", artwork: "assets/studio.jpg", deity: "assets/lilith.jpg", quote: "assets/logo.jpg" };
  const item = {
    id: "mint-" + Date.now(),
    type, title, artist: "Your Temple", blurb: blurb || "Original I AM mint",
    priceEth, priceUsdc, img: imgMap[type] || "assets/logo.jpg", creator: state.wallet
  };
  state.minted.unshift(item);
  state.owned.push(item.id);
  save();
  renderMarket();
  renderVault();
  toast("Minted to the wall · listed in Market");
  e.target.reset();
  go("market");
}

function renderVault() {
  const root = document.getElementById("vaultGrid");
  const items = catalog().filter(i => state.owned.includes(i.id));
  if (!items.length) {
    root.innerHTML = `<p class="meta">Vault is empty. Collect a relic or mint one.</p>`;
    return;
  }
  root.innerHTML = items.map(item => `
    <article class="card owned">
      <img class="cover" src="${item.img}" alt="${item.title}">
      <div class="body">
        <div class="tag">${item.type}</div>
        <h3>${item.title}</h3>
        <p class="meta">Held in session vault</p>
      </div>
    </article>`).join("");
}

function openPay(payload) {
  if (!needWallet()) return;
  state.cartItem = payload;
  state.payAsset = payload.item.asset || "usdc";
  const modal = document.getElementById("payModal");
  document.getElementById("payTitle").textContent = payload.item.title;
  document.getElementById("payEth").textContent = payload.item.priceEth + " ETH";
  document.getElementById("payUsdc").textContent = payload.item.priceUsdc + " USDC";
  highlightPay();
  modal.style.display = "grid";
}

function highlightPay() {
  document.querySelectorAll(".pay-opt").forEach(el => el.classList.toggle("on", el.dataset.asset === state.payAsset));
}

function confirmPay() {
  const p = state.cartItem;
  if (!p) return;
  const paid = state.payAsset === "eth" ? `${p.item.priceEth} ETH` : `${p.item.priceUsdc} USDC`;
  if (p.kind === "nft") {
    state.owned.push(p.item.id);
    toast(`Collected ${p.item.title} for ${paid}`);
  } else if (p.kind === "ticket") {
    state.tickets.push(p.item.id);
    toast(`Ticket burned-in · ${paid}`);
    enterStage(p.item.id);
  } else if (p.kind === "shout") {
    state.shoutouts.push({
      name: p.item.name, message: p.item.message, asset: state.payAsset, paid,
      time: new Date().toLocaleString()
    });
    document.getElementById("shoutForm").reset();
    toast(`Shoutout queued · ${paid}`);
    renderShoutouts();
  }
  save();
  renderMarket();
  renderStage();
  renderVault();
  closePay();
}

function closePay() {
  document.getElementById("payModal").style.display = "none";
  state.cartItem = null;
}

function drawSigil() {
  const intent = document.getElementById("sigilIntent").value.trim().toUpperCase();
  const box = document.getElementById("sigilBox");
  if (!intent) { box.textContent = "WRITE THE WILL"; return; }
  const reduced = intent.replace(/[AEIOU\s]/g, "").slice(0, 12) || "IAM";
  box.textContent = reduced.split("").join(" · ");
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-go]").forEach(el => el.addEventListener("click", e => {
    e.preventDefault();
    go(el.dataset.go);
  }));
  document.querySelectorAll(".nav-links a").forEach(a => a.addEventListener("click", e => {
    e.preventDefault();
    go(a.dataset.page);
  }));
  document.getElementById("walletBtn").addEventListener("click", connectWallet);
  document.getElementById("mintForm").addEventListener("submit", mintNft);
  document.getElementById("shoutForm").addEventListener("submit", submitShout);
  document.getElementById("sigilIntent").addEventListener("input", drawSigil);
  document.querySelectorAll(".chip").forEach(chip => chip.addEventListener("click", () => {
    state.filter = chip.dataset.filter;
    document.querySelectorAll(".chip").forEach(c => c.classList.toggle("on", c === chip));
    renderMarket();
  }));
  document.querySelectorAll(".pay-opt").forEach(el => el.addEventListener("click", () => {
    state.payAsset = el.dataset.asset;
    highlightPay();
  }));
  renderMarket();
  renderStage();
  renderShoutouts();
  renderVault();
});
