# I AM

Graffiti-temple music app: collect and mint music, spells, sigils, beats, deity art, and quotes. Pay for virtual performances and on-mic shoutouts in **USDC or ETH**.

## Run it

Open `index.html` in a browser (double-click, or serve the folder):

```bash
cd iam-app
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.

## What’s real vs demo

Working in this prototype:

- Full visual system (gold foil + magenta drip + tarot + street luxury)
- Market filters and catalog
- Local “wallet connect”
- Mint studio (writes into Market + Vault)
- Stage tickets + 528Hz preview tone
- Paid shoutout queue
- Sigil reducer in the Grimoire
- Checkout rail picker (USDC / ETH)

Not wired yet (on purpose):

- Real Coinbase CDP / Base transfers
- On-chain NFT contracts (ERC-721)
- Audio file hosting / livestream
- Account login beyond this browser

## Next build (when you want chain)

1. Secret API Key + Wallet Secret from [CDP Portal](https://portal.cdp.coinbase.com)
2. Create-transfer for USDC/ETH ticket + shoutout payments
3. ERC-721 on Base for music / spell / sigil collections
4. Replace demo wallet with Coinbase Wallet / wagmi

Brand art lives in `assets/`.
